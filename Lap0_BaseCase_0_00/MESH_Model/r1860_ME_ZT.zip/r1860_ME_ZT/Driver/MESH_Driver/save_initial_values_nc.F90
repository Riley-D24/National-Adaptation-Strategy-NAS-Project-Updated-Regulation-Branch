!>
!> Description:
!>  Subroutine to save initial states of variables to file. Variables
!>  shared by SA_MESH are accessible by 'sa_mesh_variables'.
!>  Other variables are accessible by their respecitve process
!>  module(s).
!>
subroutine save_initial_states_nc(fls, shd, fname, ierr)

    use model_files_variables
    use sa_mesh_common
    use nc_io

    implicit none

    !> Input variables.
    type(fl_ids):: fls
    type(ShedGridParams) :: shd
    character(len = *), intent(in) :: fname

    !> Output variables.
    integer, intent(out) :: ierr

    !> Local variables.
    character(len = DEFAULT_LINE_LENGTH) line
    character(len = SHORT_FIELD_LENGTH) field        !> ME
!-    real, dimension(:), allocatable :: dat1_r(:), dat2_r(:, :), dat3_r(:, :, :), dat4_r(:, :, :, :)
    real, dimension(:), allocatable :: dat_xy(:, :), dat_xym(:, :, :), dat_xylm(:, :, :, :), dat_xycm(:, :, :, :)
    real, dimension(:), allocatable :: dat_xm(:, :), dat_xlm(:, :, :), dat_xcm(:, :, :)
    real, parameter :: NO_DATA = -999.999
    integer iun, m, l, c, x, y, v, j, i, z

    !> Initialize the return status.
    ierr = 0
#ifdef NETCDF

    !> Reset spacing for screen output.
    call reset_tab()

    !> Open output file.
    z = 0
    line = trim(fname) !'MESH_initial_values.nc'
!-    call reset_tab()
!-    call print_message('SAVING: ' // trim(line))
!-    call increase_tab()
!-    call nc4_open_output(line, iun, z)
    call nc4_open_output(line, iun = iun, ierr = ierr)
    if (ierr /= 0) return

    !> Add projection.
!-    if (z == 0) call nc4_add_proj(iun, line, shd%CoordSys%Proj, shd%CoordSys%Ellips, shd%CoordSys%Zone, z)
    if (z == 0) then
        call nc4_add_projection( &
            iun, shd%CoordSys%Proj, &
            shd%CoordSys%Ellips, shd%CoordSys%Zone, shd%CoordSys%earth_radius, shd%CoordSys%grid_north_pole_latitude, &
            shd%CoordSys%grid_north_pole_longitude, &
            ierr = z)
    end if

    !> Add dimensions.
!-    allocate(dat1_r(shd%xCount))
!-    do i = 1, shd%xCount
!-        dat1_r(i) = (shd%xOrigin + shd%xDelta*i) - shd%xDelta/2.0
!-    end do
!-    if (z == 0) call nc4_define_dimension(iun, line, 'lon', x, z, dim_length = size(dat1_r))
!-    if (z == 0) then
!-        call nc4_add_variable_n_nf90_float(iun, line, 'longitude', 'longitude', 'degrees_east', NO_DATA, dat1_r, x, i, z)
!-    end if
!-    deallocate(dat1_r)
!-    allocate(dat1_r(shd%yCount))
!-    do i = 1, shd%yCount
!-        dat1_r(i) = (shd%yOrigin + shd%yDelta*i) - shd%yDelta/2.0
!-    end do
!-    if (z == 0) call nc4_define_dimension(iun, line, 'lat', y, z, dim_length = size(dat1_r))
!-    if (z == 0) then
!-        call nc4_add_variable_n_nf90_float(iun, line, 'latitude', 'latitude', 'degrees_north', NO_DATA, dat1_r, y, i, z)
!-    end if
!-    deallocate(dat1_r)
    if (z == 0) then
!<< ME Oct 16, 2023
      if (SHDFILEFMT == 5) then
        call nc4_define_dimension(iun, 'subbasin', dim_length = shd%xCount, did = x, ierr = z)
        call nc4_add_variable(iun, 'subbasin', x, shd%xxx, ierr = z)
        call nc4_add_variable(iun, 'lon', x, shd%CoordSys%lon, ierr = z)
        call nc4_add_variable(iun, 'lat', x, shd%CoordSys%lat, ierr = z)
       !call nc4_set_coordinate_units(iun, shd%CoordSys%Proj, vrlat = vry, vrlon = vrx, vlat = vy, vlon = vx, ierr = z)
      else
!>> ME Oct 16, 2023
        call nc4_add_coordinates( &
            iun, shd%CoordSys%Proj, &
            shd%CoordSys%lat, shd%CoordSys%lon, shd%CoordSys%rlat, shd%CoordSys%rlon, &
            shd%CoordSys%xylat, shd%CoordSys%xylon, &
            shd%CoordSys%Ellips, shd%CoordSys%Zone, shd%CoordSys%earth_radius, shd%CoordSys%grid_north_pole_latitude, &
            shd%CoordSys%grid_north_pole_longitude, &
            dim1_id = y, dim2_id = x, &
            ierr = z)
      end if
    end if  ! ME Oct 16, 2023
!-    if (z == 0) call nc4_define_dimension(iun, line, 'level', l, z, dim_length = shd%lc%IGND)
    if (z == 0) call nc4_define_dimension(iun, 'level', dim_length = shd%lc%IGND, did = l, ierr = z)
!-    if (z == 0) call nc4_define_dimension(iun, line, 'subtile_types', c, z, dim_length = 4)
    if (z == 0) call nc4_define_dimension(iun, 'subtile_types', dim_length = 4, did = c, ierr = z)
!-    if (z == 0) call nc4_define_dimension(iun, line, 'gru', m, z, dim_length = shd%lc%NTYPE)
    if (z == 0) call nc4_define_dimension(iun, 'gru', dim_length = shd%lc%NTYPE, did = m, ierr = z)
!<< ME Oct 16, 2023 for debugging
        ! write(field, FMT_GEN) shd%xCount
        ! call print_message('Total number of Columns: ' // trim(adjustl(field)))
        ! write(field, FMT_GEN) shd%yCount
        ! call print_message('Total number of Rows: ' // trim(adjustl(field)))    
!<< ME Oct 16, 2023 - Added condition on SHDFILEFMT
    !> 3-D & 4-D tile variables (x, y, m).
!-    allocate(dat3_r(shd%xCount, shd%yCount, shd%lc%NTYPE), dat4_r(shd%xCount, shd%yCount, max(shd%lc%IGND, 4), shd%lc%NTYPE))
    if (SHDFILEFMT == 5) then
      allocate( &
        dat_xm(shd%xCount, shd%lc%NTYPE), dat_xlm(shd%xCount, shd%lc%IGND, shd%lc%NTYPE), &
        dat_xcm(shd%xCount, 4, shd%lc%NTYPE))
      if (z == 0) then  ! tile_albs
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%albsno(i)
        end do
        call nc4_add_variable( &
          iun, 'tile_albs', x, m, dat_xm, long_name = 'Tile-based values for albs', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_cmas
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%cmas(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_cmas', x, m, dat_xm, long_name = 'Tile-based values for cmas', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_gro
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%gro(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_gro', x, m, dat_xm, long_name = 'Tile-based values for gro', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_qac
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%qacan(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_qac', x, m, dat_xm, long_name = 'Tile-based values for qac', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_rcan
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%lqwscan(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_rcan', x, m, dat_xm, long_name = 'Tile-based values for rcan', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_rhos
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%rhosno(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_rhos', x, m, dat_xm, long_name = 'Tile-based values for rhos', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_sncan
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%fzwscan(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_sncan', x, m, dat_xm, long_name = 'Tile-based values for sncan', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_sno
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%sno(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_sno', x, m, dat_xm, long_name = 'Tile-based values for sno', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tac
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%tacan(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_tac', x, m, dat_xm, long_name = 'Tile-based values for tac', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tbas
          dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%tbas(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_tbas', x, m, dat_xm, long_name = 'Tile-based values for tbas', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then    ! tile_tcan
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%tcan(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_tcan', x, m, dat_xm, long_name = 'Tile-based values for tcan', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tbar
        dat_xlm = NO_DATA
        do j = 1, shd%lc%IGND
          do i = 1, shd%lc%NML
            dat_xlm(shd%lc%ILMOS(i), j, shd%lc%JLMOS(i)) = vs%tile%tsol(i, j)
          end do
        end do
        call nc4_add_variable( &
            iun, 'tile_tbar', x, l, m, dat_xlm, long_name = 'Tile-based values for tbar', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_thic
        dat_xlm = NO_DATA
        do j = 1, shd%lc%IGND
          do i = 1, shd%lc%NML
            dat_xlm(shd%lc%ILMOS(i), j, shd%lc%JLMOS(i)) = vs%tile%thicsol(i, j)
          end do
        end do
        call nc4_add_variable( &
            iun, 'tile_thic', x, l, m, dat_xlm, long_name = 'Tile-based values for thic', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_thlq
      dat_xlm = NO_DATA
        do j = 1, shd%lc%IGND
          do i = 1, shd%lc%NML
            dat_xlm(shd%lc%ILMOS(i), j, shd%lc%JLMOS(i)) = vs%tile%thlqsol(i, j)
          end do
        end do
        call nc4_add_variable( &
            iun, 'tile_thlq', x, l, m, dat_xlm, long_name = 'Tile-based values for thlq', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tpnd
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%tpnd(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_tpnd', x, m, dat_xm, long_name = 'Tile-based values for tpnd', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tsfs
        dat_xcm = NO_DATA
        do j = 1, 4
          do i = 1, shd%lc%NML
            dat_xcm(shd%lc%ILMOS(i), j, shd%lc%JLMOS(i)) = vs%tile%tsfs(i, j)
          end do
        end do
        call nc4_add_variable( &
            iun, 'tile_tsfs', x, c, m, dat_xcm, long_name = 'Tile-based values for tsfs', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tsno
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%tsno(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_tsno', x, m, dat_xm, long_name = 'Tile-based values for tsno', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_wsno  
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%lqwssno(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_wsno', x, m, dat_xm, long_name = 'Tile-based values for wsno', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_zpnd
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%zpnd(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_zpnd', x, m, dat_xm, long_name = 'Tile-based values for zpnd', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_lzs
        dat_xm = NO_DATA
        do i = 1, shd%lc%NML
          dat_xm(shd%lc%ILMOS(i), shd%lc%JLMOS(i)) = vs%tile%stggw(i)
        end do
        call nc4_add_variable( &
            iun, 'tile_lzs', x, m, dat_xm, long_name = 'Tile-based values for lzs', fill = NO_DATA, ierr = z)
      end if
    else
!>> ME Oct 16, 2023 - Added condition on SHDFILEFMT
      allocate( &
        dat_xym(shd%xCount, shd%yCount, shd%lc%NTYPE), dat_xylm(shd%xCount, shd%yCount, shd%lc%IGND, shd%lc%NTYPE), &
        dat_xycm(shd%xCount, shd%yCount, 4, shd%lc%NTYPE))    
      if (z == 0) then  ! tile_albs
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
          dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%albsno(i)
        end do
!-      call nc4_add_variable_xym(iun, line, 'tile_albs', 'Tile-based values for albs', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
          iun, 'tile_albs', x, y, m, dat_xym, long_name = 'Tile-based values for albs', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_cmas
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%cmas(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_cmas', 'Tile-based values for cmas', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_cmas', x, y, m, dat_xym, long_name = 'Tile-based values for cmas', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_gro
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%gro(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_gro', 'Tile-based values for gro', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable(iun, 'tile_gro', x, y, m, dat_xym, long_name = 'Tile-based values for gro', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_qac
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%qacan(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_qac', 'Tile-based values for qac', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable(iun, 'tile_qac', x, y, m, dat_xym, long_name = 'Tile-based values for qac', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_rcan
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%lqwscan(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_rcan', 'Tile-based values for rcan', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_rcan', x, y, m, dat_xym, long_name = 'Tile-based values for rcan', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_rhos
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%rhosno(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_rhos', 'Tile-based values for rhos', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_rhos', x, y, m, dat_xym, long_name = 'Tile-based values for rhos', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_sncan
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%fzwscan(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_sncan', 'Tile-based values for sncan', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_sncan', x, y, m, dat_xym, long_name = 'Tile-based values for sncan', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_sno
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%sno(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_sno', 'Tile-based values for sno', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable(iun, 'tile_sno', x, y, m, dat_xym, long_name = 'Tile-based values for sno', fill = NO_DATA, ierr = z)
      end if   
      if (z == 0) then  ! tile_tac
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%tacan(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_tac', 'Tile-based values for tac', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable(iun, 'tile_tac', x, y, m, dat_xym, long_name = 'Tile-based values for tac', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tbas	!< ME Oct 16, 2023 start of moved block
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%tbas(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_tbas', 'Tile-based values for tbas', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_tbas', x, y, m, dat_xym, long_name = 'Tile-based values for tbas', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tcan  
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%tcan(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_tcan', 'Tile-based values for tcan', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_tcan', x, y, m, dat_xym, long_name = 'Tile-based values for tcan', fill = NO_DATA, ierr = z)
      end if	! > ME Oct 16, 2023 end of moved block
      if (z == 0) then  ! tile_tbar
        dat_xylm = NO_DATA
        do j = 1, shd%lc%IGND
            do i = 1, shd%lc%NML
                dat_xylm(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), j, shd%lc%JLMOS(i)) = vs%tile%tsol(i, j)
            end do
        end do
!-        call nc4_add_variable_xylm( &
!-            iun, line, 'tile_tbar', 'Tile-based values for tbar', '1', NO_DATA, &
!-            dat4_r(:, :, 1:shd%lc%IGND, :), x, y, l, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_tbar', x, y, l, m, dat_xylm, long_name = 'Tile-based values for tbar', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_thic
        dat_xylm = NO_DATA
        do j = 1, shd%lc%IGND
            do i = 1, shd%lc%NML
                dat_xylm(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), j, shd%lc%JLMOS(i)) = vs%tile%thicsol(i, j)
            end do
        end do
!-        call nc4_add_variable_xylm(iun, line, 'tile_thic', 'Tile-based values for thic', '1', NO_DATA, &
!-            dat4_r(:, :, 1:shd%lc%IGND, :), x, y, l, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_thic', x, y, l, m, dat_xylm, long_name = 'Tile-based values for thic', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_thlq
        dat_xylm = NO_DATA
        do j = 1, shd%lc%IGND
            do i = 1, shd%lc%NML
                dat_xylm(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), j, shd%lc%JLMOS(i)) = vs%tile%thlqsol(i, j)
            end do
        end do
!-        call nc4_add_variable_xylm(iun, line, 'tile_thlq', 'Tile-based values for thlq', '1', NO_DATA, &
!-            dat4_r(:, :, 1:shd%lc%IGND, :), x, y, l, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_thlq', x, y, l, m, dat_xylm, long_name = 'Tile-based values for thlq', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tpnd
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%tpnd(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_tpnd', 'Tile-based values for tpnd', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_tpnd', x, y, m, dat_xym, long_name = 'Tile-based values for tpnd', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tsfs    
        dat_xycm = NO_DATA
        do j = 1, 4
            do i = 1, shd%lc%NML
                dat_xycm(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), j, shd%lc%JLMOS(i)) = vs%tile%tsfs(i, j)
            end do
        end do
!-        call nc4_add_variable_xylm(iun, line, 'tile_tsfs', 'Tile-based values for tsfs', '1', NO_DATA, &
!-            dat4_r(:, :, 1:4, :), x, y, c, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_tsfs', x, y, c, m, dat_xycm, long_name = 'Tile-based values for tsfs', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_tsno
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%tsno(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_tsno', 'Tile-based values for tsno', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_tsno', x, y, m, dat_xym, long_name = 'Tile-based values for tsno', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_wsno
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%lqwssno(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_wsno', 'Tile-based values for wsno', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_wsno', x, y, m, dat_xym, long_name = 'Tile-based values for wsno', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_zpnd
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%zpnd(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_zpnd', 'Tile-based values for zpnd', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable( &
            iun, 'tile_zpnd', x, y, m, dat_xym, long_name = 'Tile-based values for zpnd', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! tile_lzs
        dat_xym = NO_DATA
        do i = 1, shd%lc%NML
            dat_xym(shd%xxx(shd%lc%ILMOS(i)), shd%yyy(shd%lc%ILMOS(i)), shd%lc%JLMOS(i)) = vs%tile%stggw(i)
        end do
!-        call nc4_add_variable_xym(iun, line, 'tile_lzs', 'Tile-based values for lzs', '1', NO_DATA, dat3_r, x, y, m, v, z)
        call nc4_add_variable(iun, 'tile_lzs', x, y, m, dat_xym, long_name = 'Tile-based values for lzs', fill = NO_DATA, ierr = z)
      end if
    end if
!-    deallocate(dat3_r, dat4_r)

    !> 2-D Grid variables (x, y).
!-    allocate(dat2_r(shd%xCount, shd%yCount))
!<< ME OCt 16, 2023 - Added condition on SHDFILEFMT
    if (SHDFILEFMT == 5) then
      if (z == 0) then  ! grid_qi 
        call nc4_add_variable( &
            iun, 'grid_qi', x, vs%grid%qi, long_name = 'Grid-based values for qi', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! grid_stgch
        call nc4_add_variable( &
            iun, 'grid_stgch', x, vs%grid%stgch, long_name = 'Grid-based values for stgch', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! grid_qo 
        call nc4_add_variable( &
            iun, 'grid_qo', x, vs%grid%qo, long_name = 'Grid-based values for qo', fill = NO_DATA, ierr = z)
      end if
    else
!>> ME Oct 16, 2023 - Added condition on SHDFILEFMT
      allocate(dat_xy(shd%xCount, shd%yCount))
      if (z == 0) then  ! grid_qi
        dat_xy = NO_DATA
        do i = 1, shd%NA
            dat_xy(shd%xxx(i), shd%yyy(i)) = vs%grid%qi(i)
        end do
!-        call nc4_add_variable_xy(iun, line, 'grid_qi', 'Grid-based values for qi', '1', NO_DATA, dat2_r, x, y, j, z)
        call nc4_add_variable(iun, 'grid_qi', x, y, dat_xy, long_name = 'Grid-based values for qi', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! grid_stgch
        dat_xy = NO_DATA
        do i = 1, shd%NA
            dat_xy(shd%xxx(i), shd%yyy(i)) = vs%grid%stgch(i)
        end do
!-        call nc4_add_variable_xy(iun, line, 'grid_stgch', 'Grid-based values for stgch', '1', NO_DATA, dat2_r, x, y, j, z)
        call nc4_add_variable(iun, 'grid_stgch', x, y, dat_xy, long_name = 'Grid-based values for stgch', fill = NO_DATA, ierr = z)
      end if
      if (z == 0) then  ! grid%qo        
        dat_xy = NO_DATA
        do i = 1, shd%NA
            dat_xy(shd%xxx(i), shd%yyy(i)) = vs%grid%qo(i)
        end do
!-        call nc4_add_variable_xy(iun, line, 'grid_qo', 'Grid-based values for qo', '1', NO_DATA, dat2_r, x, y, j, z)
        call nc4_add_variable(iun, 'grid_qo', x, y, dat_xy, long_name = 'Grid-based values for qo', fill = NO_DATA, ierr = z)
      end if
    end if
!-    deallocate(dat2_r)

    !> Close file.
    if (z == 0) then
        call nc4_close_file(iun, line, ierr = z)
    end if
    if (z /= 0) then
!-        call print_error('An error occured writing the file: ' // trim(line))
        ierr = 1
!-        return
    end if
#endif

end subroutine
