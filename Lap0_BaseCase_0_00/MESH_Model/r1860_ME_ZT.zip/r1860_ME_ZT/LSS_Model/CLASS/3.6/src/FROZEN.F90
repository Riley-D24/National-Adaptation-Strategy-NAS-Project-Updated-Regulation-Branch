SUBROUTINE FROZEN(FI,SNOWMELT,TS,SOIL_MOIST,SWE, &
                  SOIL_POR_MAX,SOIL_DEPTH,S0,T_ICE_LENS, &
                  t0_ACC,C,DELT,NCOUNT,ILG,IL1,IL2, &
                  SI,TSI,INFILTYPE,SNOWMELTD,SNOWMELTD_LAST, &
                  MELTRUNOFF,SNOWINFIL,CUMSNOWINFIL,PEAKSWE)
!>=========================================================================================
!> December 20, 2010 - Z.K Tesemma
!>=========================================================================================
!> DESCRIPTION: For a frozen soil the frozen module partitions snow melt runoff into  
!>              infiltration and runoff using Gray et al, 2001. The
!>              subroutine is adapted from the FROZEN module of CRHM.
!>
!> REFERENCE: 
!> 1. Pomeroy et al, 2007 - The cold regions hydrological model: a platform for 
!>                          basing process representation and model structure 
!>                          on physical evidence, Hydrological Processes 21: 
!>                          2650 - 2667 
!> 2. Gray et al, 2001 - Estimating areal snowmelt infiltration into frozen 
!>                       soils, Hydrological Processes 15: 3095 - 3111 
!> 3. Zhao and Gray, 1999 - Estimating areal snowmelt infiltration into frozen
!>                          soils, Hydrological Processes 13: 1827 - 1842 
!> 4. Zhao and Gray, 1997 - A parameteric expression for estimating 
!>                          infiltration into frozen soils, Hydrological 
!>                          Processes 11: 1761 - 1775
!>=========================================================================================
!> Incoming variables
!>
!> FROZENSOILINFILFLAG-  Flag for frozen soil infiltration calculation choices.
!>                    -  0 - use class frozen soil infiltration. 
!>                         - this corresponds to unlimited infiltration.
!>                    -  1 - use frozen soil infiltration by Gray et al, 2001,
!>                         - with opportunity time based on Zhao and Gray, 1997.
!>                         - or with user provided values, for approximate estimate,  
!>                         - one can use class outputs for snow accumulation time series. 
!> FI                 -  Fractional area
!> DELZ1              -  Top soil layer depth (m)
!> SNOWMELT           -  Melt rate at the bottom of snowpack (m/sec)
!> TS                 -  Temperature of top soil layer (�k)
!> SWE                -  Snow water equivalent (mm)
!> SOIL_MOIST         -  Frozen soil moisture (mm^3/mm^3)
!> DELT               -  Model time step (sec)
!> NCOUNT             -  Number of counts in a day [1 to 48]
!>                       TO DO #1: check that ncount = 1 corresponds to 
!>                                 half an hour after mid night.
!> Outgoing variables:
!>
!> t0_ACC             -  Accumulated opportunity time (hr)
!> TSI                -  Initial soil temperature (�C)
!> SI                 -  Initial soil moisture (mm^3/mm^3)
!> INFILTYPE          -  Infiltration type
!> SNOWINFIL          -  Melt infiltration (mm/sec)
!> CUMSNOWINFIL       -  Cumulative melt infiltration (mm)
!> MELTRUNOFF         -  Melt runoff (mm/sec)
!> CUMMELTRUNOFF      -  Cumulative melt runoff (mm)
!> SNOWMELTD          -  Daily snow melt (mm)
!> SNOWMELTD_LAST     -  Yesterday's snowmelt (mm)
!>
!> Parameters:
!>
!> SOIL_POR_MAX       -  Maximum soil porosity (mm^3/mm^3) [ 0 - 1]
!> SOIL_DEPTH         -  Depth from surface to bottom of rooting zone for maximum water holding capacity, m
!> S0                 -  Surface saturation during melting (mm^3/mm^3) [0 - 1]
!> C                  -  Coefficient for the frozen soil infiltration parameteric equation
!>                    -  Ranges vary from 1 to 3 -> Prairie value = 2.1, Boreal Forest value =1.14  
!> T_ICE_LENS         -  Overnight minimum temperature to cause ice lens after major melt (�C)
!>
!> Local temporary variables:
!> t0                 -  Opportunity time (hr)
!> INF                -  Cumulative frozen soil infiltration (mm)
!> INF0               -  Frozen soil infiltration rate (mm)
!> MAX_SOIL_STORAGE   -  Maximum top frozen soil water holding capacity (mm)
!>
USE FLAGS
IMPLICIT NONE
!> INCOMING
INTEGER NCOUNT,ILG,IL1,IL2
REAL    DELT,t0_ACC,SOIL_POR_MAX,SOIL_DEPTH,S0,T_ICE_LENS
REAL    FI(ILG),SWE(ILG),SNOWMELT(ILG),TS(ILG), &
        SOIL_MOIST(ILG),C(ILG)
!> OUTGOING
INTEGER INFILTYPE(ILG)
REAL    SI(ILG),TSI(ILG),SNOWMELTD(ILG),SNOWMELTD_LAST(ILG), &
        SNOWINFIL(ILG),CUMSNOWINFIL(ILG),MELTRUNOFF(ILG), &
		AVE_SOIL_STORAGE(ILG),INF(ILG),INF0(ILG),t0(ILG),PEAKSWE(ILG)
		
!> LOCAL VARIABLE
INTEGER I
!> REAL  t0,INF,INF0
!>
!>  Initialize snow infiltration and melt runoff.
SNOWINFIL  = SNOWMELT
MELTRUNOFF = 0.0				  
!>
DO I = IL1, IL2
!>  The water holding capacity of frozen soil (m/s)
	AVE_SOIL_STORAGE(I) = MAX(0.0,(SOIL_DEPTH*(SOIL_POR_MAX - SOIL_MOIST(I))/DELT))
!>  Find the peak SWE
    IF (SWE(I) > PEAKSWE(I)) THEN
	PEAKSWE(I) = SWE(I)
    ENDIF
!>  GRU exists and frozen module is active.
IF(FI(I) > 0.01 .and. C(I) > 0.0) THEN
!>  Store end of day's snow melt as yesterday's snow melt and reset daily snow melt to zero.
    IF(NCOUNT == 1) THEN
    SNOWMELTD_LAST(I) = SNOWMELTD(I)
    SNOWMELTD(I) = 0.0
    ENDIF
!>  Compute daily snow melt.
    SNOWMELTD(I) = SNOWMELTD(I) + SNOWMELT(I)*DELT	
!>	Check if snow is melting
IF(SNOWMELT(I) > 0.0) THEN
!>  Case 1: Check for ice lens formation at the beginning of the day 	
    IF(TS(I) <= T_ICE_LENS .and. SNOWMELTD_LAST(I) > 0.005) THEN
!>  Restrict infiltration 
    SNOWINFIL(I) = 0.0
    MELTRUNOFF(I) = SNOWMELT(I)
    ELSE	
!>  Case 2: Check for the initial soil saturation at the start of infiltration
    IF(SI(I) >= 1.0) THEN
!>  Restrict infiltration 
    SNOWINFIL(I) = 0.0
    MELTRUNOFF(I) = SNOWMELT(I)
    ELSEIF(SI(I) <= 0.0) THEN
    SNOWINFIL(I) = SNOWMELT(I)
	MELTRUNOFF(I) = 0.0
    ELSE
!>  Opportunity time (user specified or computed).
    IF(t0_ACC == 0.0) THEN
!>  Compute opportunity time [hours] based on Zhao and Gray, 1997.
    t0(I) = MAX(DELT/3600.0,(0.65*PEAKSWE(I)-5.0))                     !> DELT is model time step
    ELSE
!>  User provided opportunity time.
    t0(I) = t0_ACC
    ENDIF
!>  Frozen soil infiltration parameteric equation (t0 in hr, INF in mm)	  
	INF(I) = C(I)*(S0**2.92)*((1.0 - SI(I))**1.64)*(((0.0 - TSI(I))/273.15)**(-0.45))*(t0(I)**0.44)  
!>  convert mm to m
    INF(I) = INF(I)/1000.0
!>  convert m/s
	INF0(I) = INF(I)/(t0(I) * 3600.0)
!>  Case 3: Check mass conservation and adjust infiltration category as restricted.
    IF(CUMSNOWINFIL(I) > INF(I)) THEN
    CUMSNOWINFIL(I) = INF(I)
    SNOWINFIL(I) = 0.0
	MELTRUNOFF(I) = SNOWMELT(I)	
    ELSE
!>  Case 4: Check for storage capacity of the soil and potential infiltration capacity.	
	IF(SNOWMELT(I) <= INF0(I) .and. SNOWMELT(I) <= AVE_SOIL_STORAGE(I)) THEN
!>  Infiltrate everything else
	SNOWINFIL(I) = MIN(SNOWMELT(I),((INF(I) - CUMSNOWINFIL(I))/DELT))
	MELTRUNOFF(I) = SNOWMELT(I) - SNOWINFIL(I)
	ELSE
!>  Case 5: Cap the infiltration to the water holding capacity of frozen soil	
    SNOWINFIL(I) = MIN(INF0(I),AVE_SOIL_STORAGE(I),((INF(I) - CUMSNOWINFIL(I))/DELT)) 
	MELTRUNOFF(I) = SNOWMELT(I) - SNOWINFIL(I)
	ENDIF	 !> Check Case 4	
    ENDIF    !> Check Case 3
    ENDIF    !> Check Case 2
	ENDIF    !> Check Case 1
    
	CUMSNOWINFIL(I) = CUMSNOWINFIL(I) + SNOWINFIL(I)*DELT
	
ELSE    !> Snow melting just started so do infiltraion but update the soil saturation and temperature of the soil layer
    SI(I) = SOIL_MOIST(I)/MAX(SOIL_MOIST(I),SOIL_POR_MAX)
	TSI(I) = MIN(-0.10,TS(I))
    PEAKSWE(I) = SWE(I)
    CUMSNOWINFIL(I) = 0.0
ENDIF   !> (SNOWMELT(I) > 0.0)

ELSE
!> Reset the cummulative infiltration to zero when there is no snow cover for one day.
!> CUMSNOWINFIL(I) = 0.0
ENDIF        !> (FI(I) > 0.01 .and. C(I) > 0.0)
! ! !>
! IF(I==5)THEN
! write(9191,*)FI(5)
! write(9192,*)SWE(5)
! write(9193,*)PEAKSWE(5)
! write(9194,*)SNOWMELT(5)
! write(9195,*)SNOWMELTD(5)
! write(9196,*)SNOWMELTD_LAST(5)
! write(9197,*)SOIL_MOIST(5)
! write(9199,*)AVE_SOIL_STORAGE(5)
! write(9201,*)CUMSNOWINFIL(5)
! write(9202,*)INF(5)
! write(9203,*)INF0(5)
! write(9204,*)SI(5)
! write(9205,*)SNOWINFIL(5)
! write(9206,*)MELTRUNOFF(5)
! write(9207,*)TSI(5)
! write(9208,*)TS(5)
! write(9301,*)t0(5)
! write(9302,*)DELT
! ENDIF
! ! !>
ENDDO
                                                         
RETURN

END