!-------------------------------------- LICENCE BEGIN ------------------------------------
!Environment Canada - Atmospheric Science and Technology License/Disclaimer,
!                     version 3; Last Modified: May 7, 2008.
!This is free but copyrighted software; you can use/redistribute/modify it under the terms
!of the Environment Canada - Atmospheric Science and Technology License/Disclaimer
!version 3 or (at your option) any later version that should be found at:
!http://collaboration.cmc.ec.gc.ca/science/rpn.comm/license.html
!
!This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
!without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
!See the above mentioned License/Disclaimer for more details.
!You should have received a copy of the License/Disclaimer along with this software;
!if not, you can write to: EC-RPN COMM Group, 2121 TransCanada, suite 500, Dorval (Quebec),
!CANADA, H9P 1J3; or send e-mail to service.rpn@ec.gc.ca
!-------------------------------------- LICENCE END --------------------------------------
      SUBROUTINE SOILI_SVS (WD, &
           WF, SNM, SVM, RHOS, RHOSV, & 
           VEGH, VEGL, &  
           CGSAT, WSAT, WWILT, BCOEF, & 
           CVH, CVL, ALVH, ALVL,  & 
           EMISVH, EMISVL, ETG, RGLVH , RGLVL, STOMRVH, STOMRVL,  & 
           GAMVH,GAMVL, &  
           LAIVH, LAIVL, &   
           Z0MVH, Z0MVL, Z0, CLAY, SAND, DECI, EVER,LAID,  &  
           Z0HSNOW,Z0MBG, Z0M_TO_Z0H, &
           WTA, CG, PSNGRVL,  & 
           Z0H, ALGR, EMGR, PSNVH, PSNVHA,   &
           ALVA, LAIVA, CVPA, EVA, Z0HA, RGLA, STOMRA ,&  
           GAMVA, N )
!
        use svs_configs
        use sfc_options, only: read_emis
     implicit none
#include <arch_specific.hf>
!
      INTEGER N 
      REAL Z0HSNOW, Z0M_TO_Z0H, Z0MBG
      REAL WD(N,NL_SVS),WF(N,NL_SVS)

      REAL SNM(N), RHOS(N)
      REAL RHOSV(N), Z0MVH(N), VEGH(N), VEGL(N), SVM(N)
      REAL CGSAT(N), WSAT(N,NL_SVS), WWILT(N,NL_SVS), BCOEF(N,NL_SVS)
      REAL Z0(N)
      REAL CG(N), WTA(N,svs_tilesp1)
      REAL PSNGRVL(N)
      REAL Z0H(N), ALGR(N), CLAY(N), SAND(N)
      REAL DECI(N), EVER(N), LAID(N)
      REAL EMGR(N), PSNVH(N), PSNVHA(N),  LAIVH(N)
      REAL ALVA(N), LAIVA(N), CVPA(N), EVA(N)
      REAL LAIVL(N), CVH(N), CVL(N), ALVL(N), ALVH(N)
      REAL EMISVH(N), EMISVL(N), ETG(N), Z0MVL(N), RGLVH(N), RGLVL(N)
      REAL Z0HA(N), RGLA(N), STOMRA(N), STOMRVH(N), STOMRVL(N)
      REAL GAMVL(N), GAMVH(N), GAMVA(N)
      
      
!Author
!          S. Belair (January 1997)
!Revisions
! 001      S. Belair (November 1998)
!             Z0H calculated from Z0TOT instead of Z0
! 002      S. Belair (December 1998)
!             Correction to the thermal coefficient for bare
!             soil in order to include the effect of frozen water
! 003      S. Belair (January 2000)
!             change the roughness length of snow (now 0.005)
!             and change the formulation for "psng", i.e., the
!             fraction of bare soil covered by snow
! 004      B. Bilodeau and S. Belair (February 2000)
!             Formulation for WGEQ modified to avoid underflows
! 005      B. Bilodeau (January 2001)
!             Automatic arrays
! 006      S. Belair and L.-P. Crevier (February 2001)
!             Put roughness length of snow equal to Z0
!             Cap Z0H at 0.2 m
! 007      S. Belair (May 2007)
!             Fraction of snow coverage
!             Thermal coefficient for the vegetation
!             Effect of snow on Z0H
! 008      M. Abrahamowicz (Jan 2009)
!             Output "thermal coefficient of vegetation that
!             considers the effect of LAI" i.e. change the way
!             it is declared 
!                    
! 009     M. Abrahamowicz (Jan 2009) - small BUG correction
!         max() function must get 2 same types as input
!         i.e. replace 0 by 0.0 whenever used with real
!
! 010     M. Abrahamowicz (Jan 2009) - add calculation for
!         bare ground albedo   emissivity based on water content and soil
!         texture (sand vs. clay)
!         (September 2010) -add calculation of snow fraction for high 
!         vegetation 
!
! 011     S.Z. Husain (Feb 2012) 
!           - Add two additional superficial soil layers
!           - Add three additional subsurface (deep) soil layers
!           - Correction for calculation of CNOLEAF
!           - Compute coefficients ZC4, ZC5 and ZC6
!      
! 012     S.Z. Husain (Aug 2012)
!           - Add one more deep soil layer by changing the first 
!             deep soil layer dept to 0.1 m
! 013     M. Abrahamowicz (dec 2012): Rename soili_svs                
! 014     S. Zhang (March 2013)
!           -change the fixed Z0HA (0.01 is too small)
!
! 015     S.Z. Husain (Apr 2013)
!           - Adding two more deep soil layers and changing their
!             distribution
! 0.16    M. Abrahamowicz (Aug 2013)
!           - Impose minimum on LAI value to avoid divisions by zero.
!
!
!Object
!     Calculates the coefficients related to the soil (i.e., CG, CT,
!     ) and to the snow canopy 
!     (i.e., ZCS, psn,psnvh)
!
!Arguments
!
!
!          - Input -
! WD(NL)   soil volumetric water content in soil layer (NL soil layers)
! WF(NL)   volumetric content of frozen water in the ground
! SNM      equivalent water content of the snow reservoir
! SVM      equivalent water content of the snow-under-vegetation reservoir
! RHOS     relative density of snow
! RHOSV    relative density of snow-under-vegetation
! VEGH     fraction of HIGH vegetation
! VEGL     fraction of LOW vegetation
! CGSAT    soil thermal coefficient at saturation
! WSAT     saturated volumetric moisture content
! WWILT    wilting point volumetric water content
! BCOEF    slope of the retention curve
! LAIVH    Vegetation leaf area index for HIGH vegetation only
! LAIVH    Vegetation leaf area index for LOW  vegetation only
! Z0MVH    Local roughness associated with HIGH vegetation only (no
!          orography)
! Z0MVL    Local roughness associated with LOW vegetation only (no
!          orography)
! CV       heat capacity of the vegetation
! CVH      heat capacity of HIGH vegetation
! CVL      heat capacity of LOW  vegetation
! EMISVH   emissivity of HIGH vegetation
! EMISVL   emissivity of LOW  vegetation
! ETG      emissivity of land surface (no snow) READ AT ENTRY, 
!          USED TO STAMP ALL NO SNOW EMISSIVITIES. IF NOT READ, 
!          VARIABLE SET TO ZERO !!!!
! RGLVH    param. stomatal resistance for HIGH vegetation
! RGLVL    param. stomatal resistance for LOW  vegetation
! STOMRVH  minim. stomatal resistance for HIGH vegetation
! STOMRVL  minim. stomatal resistance for LOW  vegetation
! GAMVH    stomatal resistance param. for HIGH vegetation
! GAMVL    stomatal resistance param. for LOW  vegetation
! Z0       momentum roughness length (no snow)
! CLAY     percentage of clay in soil (mean of 3 layers)
! SAND     percentage of sand in soil (mean of 3 layers)  
! DECI     fraction of high vegetation that is deciduous
! EVER     fraction of high vegetation that is evergreen
! LAID     LAI of deciduous trees
! Z0HSNOW  Constant for thermal roughness of snow
! Z0MBG     Constant momentum roughness for bare ground
! Z0M_TO_Z0H   Conversion factor to convert from momemtum roughness
!          to thermal roughness
!
!           - Output -
! WTA      Weights for SVS surface types as seen from SPACE
! CG       heat capacity of the bare soil
! PSNGRVL  fraction of the bare soil or low veg. covered by snow
! Z0H      agg. roughness length for heat transfer considering snow
! ALGR     albedo of bare ground (soil)
! EMGR     emissivity of bare ground (soil)
! PSNVH    fraction of HIGH vegetation covered by snow
! PSNVHA   fraction of HIGH vegetation covered by snow as seen from
!          the ATMOSPHERE 
! ALVA     average vegetation albedo
! LAIVA    average vegetation LAI
! CVPA     average thermal coefficient of vegetation considering effect
!          of LAI
! EVA      average vegetation emissivity
! Z0HA      AVERAGED Local roughness associated with exposed (no snow)
!           vegetation only (also no orography), for heat transfer
! RGLA     average vegetation parameter stomatal resistance
! STOMRA   average minimum stomatal resistance
! GAMVA    average stomatal resistance param. 
!
include "thermoconsts.inc"
include "isbapar.cdk"

!
      INTEGER I
!
      REAL LAMI, CI, DAY
! 
      REAL ADRYSAND, AWETSAND, ADRYCLAY, AWETCLAY
      REAL EDRYSAND, EWETSAND, EDRYCLAY, EWETCLAY

      real, dimension(n) :: a, b, cnoleaf, cva, laivp, lams, lamsv, &
           psnground, psnlowveg, zcs, zcsv, z0_snow_low, z0_snow_high

!
!***********************************************************************
!
!
!
!
!
!                                    Define some constants for
!                                    the ice
!
!                                    NOTE:  these definitions should
!                                           be put in a COMMON
!
      LAMI   = 2.22
      CI     = 2.106E3
      DAY    = 86400.
!                       Albedo values from literature
      ADRYSAND = 0.35
      AWETSAND = 0.24
      ADRYCLAY = 0.15
      AWETCLAY = 0.08
!                       Emissivity values from van Wijk and Scholte Ubing (1963)
      EDRYSAND = 0.95
      EWETSAND = 0.98
      EDRYCLAY = 0.95
      EWETCLAY = 0.97

!
!
!
!
!
!        1.     THE HEAT CAPACITY OF BARE-GROUND
!               --------------------------------
!
!                          Actually, the 'C' coefficients in
!                          ISBA do not represent heat capacities,
!                          but rather their inverse.  So in the
!                          following formulation, CG is large
!                          when W2 is small, thus leading to small
!                          values for the heat capacity.  In other
!                          words, a small amount of energy will
!                          result in great temperature variations
!                          (for drier soils).
!
      DO I=1,N
        CG(I) = CGSAT(I) * ( WSAT(I,1)/ MAX(WD(I,1)+WF(I,1),0.001))** &
                      ( 0.5*BCOEF(I,1)/LOG(10.) )
        CG(I) = MIN( CG(I), 2.0E-5 )      
!
      END DO
!
!
!
!
!
!
!
!
!*       2.     THE HEAT CAPACITY OF THE SNOW
!               -----------------------------
!
!                          First calculate the conductivity of snow
!
      DO I=1,N
        LAMS(I) = LAMI * RHOS(I)**1.88
        ZCS(I) = 2.0 * SQRT( PI/( LAMS(I) * 1000* RHOS(I) *CI*DAY) )
!
        LAMSV(I) = LAMI * RHOSV(I)**1.88
        ZCSV(I) = 2.0 * SQRT( PI/(LAMSV(I)* 1000*RHOSV(I) *CI*DAY) )
!
      END DO    
!
!
!
!
!*       3.     FRACTIONS OF SNOW COVERAGE
!               --------------------------
!
      DO I=1,N


!                        average snow cover fraction of bare ground and low veg
         IF(SNM(I).GE.CRITSNOWMASS ) THEN

            ! use z0=0.03m for bare ground, 0.1m for low veg
             z0_snow_low(i) = exp (  (  (1-VEGH(I) -VEGL(I)) * log( 0.03) &
                                  +  VEGL(I) * log(0.1) ) / ( 1 - VEGH(I) ) )
             

             PSNGRVL(I) = MIN( SNM(I) / (SNM(I) + RHOS(I)* 5000.* z0_snow_low(i) ) , 1.0)

         ELSE

            PSNGRVL(I) = 0.0
           
         ENDIF
            
       


         IF(SVM(I).GE.CRITSNOWMASS ) THEN
!
!                       SNOW FRACTION AS SEEN FROM THE GROUND
!

            PSNVH(I)  =  MIN( SVM(I) / (SVM(I)+ RHOSV(I)*5000.*0.1 ), 1.0)
!                       SNOW FRACTION AS SEEN FROM THE SPACE
!                       NEED TO ACCOUNT FOR SHIELDING OF LEAVES/TREES
!
            PSNVHA(I) = (EVER(I) * 0.2 + DECI(I) * MAX(LAI0 - LAID(I), 0.2)) * PSNVH(I)

         ELSE
            PSNVH(I)  = 0.0
            PSNVHA(I) = 0.0
         ENDIF



!        
      END DO
!

!
!*      4.      FRACTIONS OF SVS TYPES AS SEEN FROM SPACE
!               --------------------------

      call weights_svs(VEGH,VEGL,PSNGRVL,PSNVHA,N,WTA)


!
!*      5.      AGGREGATED  VEGETATION FIELDS
!              ----------------------------------
!
!                        Here the snow cover of low vegetation
!                        is taken into account
      DO I=1,N

         IF((VEGH(I)+VEGL(I)*(1-PSNGRVL(I))).GE.EPSILON_SVS)THEN
!
!                        LEAF AREA INDEX
!
            LAIVA(I) = MAX(   ( VEGH(I) * LAIVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * LAIVL(I))  & 
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))) , EPSILON_SVS)

!
!                        LEAF AREA INDEX CONSIDERING WOODY PART
!
            LAIVP(I) =MAX(  ( VEGH(I)*MAX(LAIVH(I),0.1)+ VEGL(I)*(1.-PSNGRVL(I))*LAIVL(I)) &     
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))) , EPSILON_SVS )
!
!                        THERMAL COEFFICIENT 
!                        -- Impose min. of 1.0E-5 consistent with look-up table in inicove_svs
!
            CVA(I) = MAX(  ( VEGH(I) * CVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * CVL(I)) &     
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))) ,  1.0E-5 )
!
!                        ALBEDO
!                        -- Impose min. of 0.12 consistent with look-up table in inicove_svs
!
            ALVA(I) = MAX( ( VEGH(I) * ALVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * ALVL(I)) &     
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))) , 0.12 ) 
!
! 
!                        PARAMETER STOMATAL RESISTANCE
!                        -- Impose min. of 30. consistent with look-up table in inicove_svs
!
            RGLA(I) = MAX( ( VEGH(I) * RGLVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * RGLVL(I)) &     
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))) , 30. ) 
!
!                        LOCAL ROUGHNESS
!
            Z0HA(I) = ( VEGH(I)                  * LOG(Z0MVH(I) * Z0M_TO_Z0H) &
                     + VEGL(I) * (1.-PSNGRVL(I)) * LOG(Z0MVL(I) * Z0M_TO_Z0H)) &     
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I)))

            Z0HA(I) = EXP(Z0HA(I))
!
!                        MINIMUM STOMATAL RESISTANCE
!                        -- Impose min. of 100. consistent with look-up table in inicove_svs
!
            STOMRA(I) = MAX( ( VEGH(I) * STOMRVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * STOMRVL(I))  &    
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))) , 100.0 )
!
!                        STOMATAL RESISTANCE PARAMETER
!
            GAMVA(I) = ( VEGH(I) * GAMVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * GAMVL(I)) &     
                              / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I)))
!
         ELSE

!                       Set the coefficients parameters to lowest physical values found in look-up table
!                       to have physical values and not bogus values. Use "EPSILON" instead of 0.0 below.
!
!               
            LAIVA(I) = EPSILON_SVS
            LAIVP(I) = EPSILON_SVS
            CVA(I)   = 1.0E-5
            ALVA(I)  = 0.12
            RGLA(I)  = 30.
            Z0HA(I) = Z0M_TO_Z0H * Z0(I)  
            STOMRA(I)= 100.
            GAMVA(I) = EPSILON_SVS
         ENDIF
!                        
      END DO
!
!
!*      6.      THERMAL COEFFICIENT for VEGETATION
!               ----------------------------------
      DO I=1,N
!
        IF((VEGH(I)+VEGL(I)*(1.-PSNGRVL(I))).GE.EPSILON_SVS) THEN
!
!
!                       CNOLEAF = thermal coefficient for the leafless   
!                       portion of vegetation areas
              CNOLEAF(I) = (VEGL(I)*(1.-PSNGRVL(I)) +  &
                          VEGH(I)*(1.-PSNVH(I))) / CG(I) + PSNGRVL(I)/ZCS(I) & 
                         + PSNVH(I)/ZCSV(I)
!
!                       CVPA = thermal coefficient of vegetation that
!                       considers the effect of LAI
!
!
             IF(CNOLEAF(I).gt.0.0) THEN
                CNOLEAF(I) = (VEGL(I)+VEGH(I))/CNOLEAF(I)
             ELSE
                CNOLEAF(I) = 0.0
             ENDIF

             CVPA(I) = MIN( LAIVP(I),LAI0 ) *  CVA(I)/LAI0  & 
                     + MAX( LAI0 - LAIVP(I), 0.0 ) * CNOLEAF(I)/LAI0 
             
          ELSE

!         
!                       Set the coefficients to lowest physical values found in look-up table 
!                       to avoid division by zero
!
             CVPA(I)=1.0E-5
             CNOLEAF(I)=1.0E-5
!     
          ENDIF
!      
      ENDDO
!
!
!
!
!
!
!       7.     THERMAL ROUGHNESS LENGTH THAT CONSIDERS THE SNOW
!               ----------------------------------------
!
!                      The roughness length for heat transfers
!                      is calculated here, in ISB.  For Z0H, 
!                      the roughness length used for heat transfers, 
!                      only the local roughness is used (associated
!                      with vegetation), i.e., no orography effect
!
!                      Note that the effect of snow is only on the 
!                      thermal roughness length
!
      DO I=1,N         
         Z0H(I)=(1-PSNVHA(I)) *      VEGH(I)              * LOG(Z0MVH(I)*Z0M_TO_Z0H)+   &
                (1-PSNGRVL(I))*      VEGL(I)              * LOG(Z0MVL(I)*Z0M_TO_Z0H)+   &
                (1-PSNGRVL(I))*(1-VEGH(I)-VEGL(I))        * LOG(Z0MBG   *Z0M_TO_Z0H)+   &
                (VEGH(I)*PSNVHA(I)+(1-VEGH(I))*PSNGRVL(I))* LOG(Z0HSNOW)
 

        Z0H(I)=EXP(Z0H(I))

      END DO
!
!
!        8.     BARE GROUND ALBEDO   EMISSIVITY
!               ---------------------------------------
!
!                      The bare ground albedo   emissivity for the energy budget
!                      of the bare ground only is calculated here.
!                      It is a rough approximation based on a bi-linear
!                      interpolation of four "extreme" soil values
!                      mainly "dry-sand", "wet-sand", "dry-clay" 
!                      and "wet-clay". The albedo   emissivity of these four
!                      categories is estimated from existing 
!                      literature. Use superficial volumetric 
!                      water content to assess soil wetness as 
!                      want *surface* albedo & emissivity.
!
!                      compute relative texture and soil wetness coefficients A & B
!
!                       N.B. Even when mapping soil parameters from texture 
!                       database unto model layer, use 1st layer texture from 
!                       database as is here... 
!
      DO I=1,N
!                      A few constraints 
         IF((CLAY(I)+SAND(I)).gt.0.0) THEN         
            A(I)= SAND(I) / ( CLAY(I) + SAND(I) ) 
         ELSE         
            A(I) = 0.0           
         ENDIF
!                      If  superficial soil layer dryer than wilting point
!                      set it to wilting points ...and so get 0.0 for B(I)
!
         IF((WSAT(I,1)-WWILT(I,1)).gt.0.0.and.WD(I,1).ge.WWILT(I,1)) THEN         
            B(I) = ( WD(I,1) - WWILT(I,1) ) / ( WSAT(I,1) - WWILT(I,1))
         ELSE
            B(I) = 0.0 
         ENDIF
! 
!                      Added security for coefficients
         IF(A(I).gt.1.0) A(I)=1.0
         IF(B(I).gt.1.0) B(I)=1.0
!
      END DO

!                      Compute soil albedo
      DO I=1,N
!
         ALGR(I)      = ADRYCLAY * ( 1. - A(I) ) * ( 1. - B(I) ) & 
                      + ADRYSAND *        A(I)   * ( 1. - B(I) ) &   
                      + AWETCLAY * ( 1. - A(I) ) *        B(I)  &   
                      + AWETSAND *        A(I)   *        B(I)   

      ENDDO

!
!      
!         9.     NO-SNOW EMISSIVITIES
!               ---------------------------------------                     Compute soil albedo & emissivity 
!
!               If use "read-in"  emissivity, then stamp all emissivities with "read at entry value", 
!               otherwise calculate individual emissivities


      if ( read_emis ) then

         DO I = 1, N
            EMISVH(I)        = ETG(I)
            EMISVL(I)        = ETG(I)
            EMGR  (I)        = ETG(I)
            EVA   (I)        = ETG(I)
         ENDDO
  
      else

         DO I = 1, N
!
!                      AGGREGATED VEG. EMISSIVITY  (VEGETATION NOT COVERED BY SNOW)
!
            IF((VEGH(I)+VEGL(I)*(1-PSNGRVL(I))).GE.EPSILON_SVS)  THEN
               EVA(I) = ( VEGH(I) * EMISVH(I) + VEGL(I) * (1.-PSNGRVL(I)) * EMISVL(I)) &     
                    / (VEGH(I)+VEGL(I)*(1.-PSNGRVL(I)))
!
            ELSE
               EVA(I) = 1.0
            ENDIF
!
!                      BARE GROUND EMISSIVITY
!
            EMGR(I)       = EDRYCLAY * ( 1. - A(I) ) * ( 1. - B(I) )  &  
                          + EDRYSAND *        A(I)   * ( 1. - B(I) ) &   
                          + EWETCLAY * ( 1. - A(I) ) *        B(I) &    
                          + EWETSAND *        A(I)   *       B(I) 
            !

         ENDDO

      endif


      RETURN
      END
